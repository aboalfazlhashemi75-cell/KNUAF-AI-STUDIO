import 'dart:convert';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

void main() => runApp(const KnaufStudioApp());

const gold = Color(0xFFD6AD55);
const bg = Color(0xFF101010);
const panel = Color(0xFF1B1B1B);
const String apiBaseUrl = String.fromEnvironment(
  'KNUAF_API_URL',
  defaultValue: 'https://YOUR-SERVER-DOMAIN.com',
);

class KnaufStudioApp extends StatelessWidget {
  const KnaufStudioApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'KNUAF AI STUDIO',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.dark, surface: panel),
      appBarTheme: const AppBarTheme(backgroundColor: bg, foregroundColor: Colors.white),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: panel,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(style: ElevatedButton.styleFrom(
        backgroundColor: gold, foregroundColor: Colors.black,
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(13)),
      )),
    ),
    home: const StudioHome(),
  );
}

class StudioHome extends StatefulWidget {
  const StudioHome({super.key});
  @override
  State<StudioHome> createState() => _StudioHomeState();
}

class _StudioHomeState extends State<StudioHome> {
  int tab = 0;
  File? videoFile;
  VideoPlayerController? videoController;
  bool busy = false;
  String status = 'برای شروع، یک ویدئوی پروژه انتخاب کن.';
  String transcript = '';
  String ideas = '';
  String caption = '';
  String voiceResult = '';
  final voiceController = TextEditingController();

  @override
  void dispose() {
    videoController?.dispose();
    voiceController.dispose();
    super.dispose();
  }

  Future<void> pickVideo() async {
    final result = await FilePicker.platform.pickFiles(type: FileType.video, withData: false);
    if (result == null || result.files.single.path == null) return;
    final file = File(result.files.single.path!);
    await videoController?.dispose();
    final controller = VideoPlayerController.file(file);
    setState(() {
      videoFile = file; videoController = controller;
      transcript = ''; ideas = ''; caption = '';
      status = 'ویدئو انتخاب شد. برای پخش، دکمه اجرا را بزن.';
    });
    await controller.initialize();
    await controller.setLooping(true);
    if (mounted) setState(() {});
  }

  Future<Map<String, dynamic>> uploadFor(String endpoint, {Map<String, String>? fields}) async {
    if (videoFile == null) throw Exception('ابتدا یک ویدئو انتخاب کن.');
    if (apiBaseUrl.contains('YOUR-SERVER-DOMAIN')) throw Exception('آدرس سرور هنوز تنظیم نشده است؛ راهنمای README را ببین.');
    final request = http.MultipartRequest('POST', Uri.parse('$apiBaseUrl$endpoint'));
    request.files.add(await http.MultipartFile.fromPath('video', videoFile!.path));
    if (fields != null) request.fields.addAll(fields);
    final streamed = await request.send().timeout(const Duration(minutes: 10));
    final body = await streamed.stream.bytesToString();
    if (streamed.statusCode < 200 || streamed.statusCode >= 300) throw Exception('خطای سرور (${streamed.statusCode}): $body');
    return jsonDecode(body) as Map<String, dynamic>;
  }

  Future<void> runTask(Future<void> Function() task, String label) async {
    setState(() { busy = true; status = label; });
    try { await task(); }
    catch (e) { setState(() => status = 'خطا: $e'); }
    finally { if (mounted) setState(() => busy = false); }
  }

  Future<void> transcribe() => runTask(() async {
    final data = await uploadFor('/transcribe');
    setState(() { transcript = (data['text'] ?? '').toString(); status = 'زیرنویس متنی آماده شد.'; });
  }, 'در حال ارسال ویدئو و تشخیص گفتار فارسی...');

  Future<void> createIdeas() => runTask(() async {
    final data = await uploadFor('/content', fields: {
      'transcript': transcript,
      'business': 'اجرای کناف، سقف کاذب، نورپردازی و دکوراسیون داخلی',
      'platform': 'Instagram Reels',
      'language': 'Persian',
    });
    setState(() {
      ideas = (data['ideas'] ?? '').toString();
      caption = (data['caption'] ?? '').toString();
      status = 'ایده و کپشن آماده شد.';
    });
  }, 'هوش مصنوعی در حال بررسی محتوای پروژه...');

  Future<void> createVoice() => runTask(() async {
    if (voiceController.text.trim().isEmpty) throw Exception('متن نریشن را وارد کن.');
    if (apiBaseUrl.contains('YOUR-SERVER-DOMAIN')) throw Exception('آدرس سرور هنوز تنظیم نشده است؛ راهنمای README را ببین.');
    final response = await http.post(
      Uri.parse('$apiBaseUrl/tts'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'text': voiceController.text.trim(), 'voice': 'fa-IR-FaridNeural'}),
    ).timeout(const Duration(minutes: 3));
    if (response.statusCode != 200) throw Exception(response.body);
    setState(() { voiceResult = 'فایل صوتی ساخته شد؛ پاسخ سرور دریافت شد.'; status = 'تولید صدا انجام شد.'; });
  }, 'در حال ساخت صدای فارسی...');

  Widget goldButton(String text, VoidCallback? onPressed, {IconData icon = Icons.auto_awesome}) =>
    SizedBox(width: double.infinity, child: ElevatedButton.icon(
      onPressed: busy ? null : onPressed, icon: Icon(icon),
      label: Text(text, style: const TextStyle(fontWeight: FontWeight.bold)),
    ));

  Widget videoPreview() {
    final c = videoController;
    if (c == null || !c.value.isInitialized) {
      return Container(height: 205, width: double.infinity,
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
        child: const Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(Icons.video_library_outlined, size: 48, color: gold), SizedBox(height: 10),
          Text('پیش‌نمایش ویدئو', style: TextStyle(color: Colors.white70)),
        ]));
    }
    return ClipRRect(borderRadius: BorderRadius.circular(18), child: AspectRatio(
      aspectRatio: c.value.aspectRatio,
      child: Stack(alignment: Alignment.bottomCenter, children: [
        VideoPlayer(c),
        VideoProgressIndicator(c, allowScrubbing: true, colors: const VideoProgressColors(playedColor: gold)),
        Align(alignment: Alignment.center, child: IconButton.filled(
          style: IconButton.styleFrom(backgroundColor: Colors.black54), iconSize: 38,
          onPressed: () => setState(() => c.value.isPlaying ? c.pause() : c.play()),
          icon: Icon(c.value.isPlaying ? Icons.pause : Icons.play_arrow),
        )),
      ]),
    ));
  }

  Widget featureTile(IconData icon, String title, String subtitle, VoidCallback onTap) => Card(
    color: panel, child: ListTile(
      leading: Icon(icon, color: gold, size: 29), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      subtitle: Text(subtitle, style: const TextStyle(color: Colors.white60)),
      trailing: const Icon(Icons.chevron_right), onTap: onTap,
    ));

  Widget homePage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('استودیوی هوشمند تولید ریلز', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 6),
    const Text('از فیلم خام پروژه تا محتوای آماده اینستاگرام', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18), videoPreview(), const SizedBox(height: 12),
    OutlinedButton.icon(onPressed: busy ? null : pickVideo, icon: const Icon(Icons.add_to_photos_outlined, color: gold),
      label: Text(videoFile == null ? 'انتخاب ویدئو از گوشی' : 'انتخاب ویدئوی دیگر')),
    if (videoFile != null) Padding(padding: const EdgeInsets.only(top: 8),
      child: Text(videoFile!.path.split(Platform.pathSeparator).last, maxLines: 1, overflow: TextOverflow.ellipsis,
        style: const TextStyle(color: Colors.white54))),
    const SizedBox(height: 18),
    featureTile(Icons.subtitles, 'زیرنویس هوشمند', 'تبدیل گفتار ویدئو به متن فارسی', () => setState(() => tab = 1)),
    featureTile(Icons.graphic_eq, 'تبدیل متن به صدا', 'ساخت نریشن فارسی با صدای انتخابی', () => setState(() => tab = 2)),
    featureTile(Icons.lightbulb_outline, 'ایده و کپشن هوشمند', 'ایده ریلز، سناریو، کپشن و هشتگ', () => setState(() => tab = 3)),
    const SizedBox(height: 14),
    Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(14)),
      child: Row(children: [const Icon(Icons.info_outline, color: gold), const SizedBox(width: 10),
        Expanded(child: Text(status, style: const TextStyle(color: Colors.white70)))])),
  ]);

  Widget captionsPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('زیرنویس هوشمند فارسی', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('صدای ویدئو با سرویس تشخیص گفتار به متن تبدیل می‌شود.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 18),
    goldButton('استخراج زیرنویس از ویدئو', videoFile == null ? null : transcribe, icon: Icons.subtitles),
    const SizedBox(height: 16),
    TextFormField(initialValue: transcript, key: ValueKey(transcript), maxLines: 10,
      onChanged: (v) => transcript = v,
      decoration: const InputDecoration(hintText: 'متن تشخیص داده‌شده اینجا نمایش داده می‌شود...')),
    const SizedBox(height: 8),
    const Text('نسخه بعدی: استایل زیرنویس، خروجی SRT و زیرنویس چسبیده به تصویر.',
      style: TextStyle(color: Colors.white54, fontSize: 12)),
  ]);

  Widget voicePage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('استودیوی تبدیل متن به صدا', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8), const Text('متن نریشن را بنویس تا با صدای فارسی تولید شود.', style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 16),
    TextField(controller: voiceController, maxLines: 7,
      decoration: const InputDecoration(hintText: 'مثلاً: در این پروژه، طراحی و اجرای سقف کاذب با نور خطی را می‌بینید...')),
    const SizedBox(height: 12),
    const ListTile(contentPadding: EdgeInsets.zero, leading: Icon(Icons.record_voice_over, color: gold),
      title: Text('صدای فعلی: فارسی مردانه'), subtitle: Text('fa-IR-FaridNeural • قابل تغییر در نسخه‌های بعدی')),
    goldButton('تولید فایل صوتی', createVoice, icon: Icons.graphic_eq),
    if (voiceResult.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12),
      child: Text(voiceResult, style: const TextStyle(color: gold))),
  ]);

  Widget aiPage() => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('دستیار هوشمند محتوا', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('با استفاده از زیرنویس و توضیحات کسب‌وکار، ایده و کپشن مخصوص پروژه پیشنهاد می‌شود.',
      style: TextStyle(color: Colors.white60)),
    const SizedBox(height: 16),
    goldButton('تحلیل ویدئو و ساخت ایده و کپشن', videoFile == null ? null : createIdeas, icon: Icons.auto_awesome),
    const SizedBox(height: 18),
    if (ideas.isNotEmpty) ...[
      const Text('ایده‌ها و سناریو', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: gold)),
      const SizedBox(height: 8), SelectableText(ideas), const SizedBox(height: 18),
    ],
    if (caption.isNotEmpty) ...[
      const Text('کپشن پیشنهادی', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold, color: gold)),
      const SizedBox(height: 8), SelectableText(caption),
    ],
    if (ideas.isEmpty && caption.isEmpty) const Text('پس از استخراج زیرنویس، ایده ریلز و کپشن اینجا نمایش داده می‌شود.',
      style: TextStyle(color: Colors.white54)),
  ]);

  @override
  Widget build(BuildContext context) {
    final pages = [homePage(), captionsPage(), voicePage(), aiPage()];
    return Directionality(textDirection: TextDirection.rtl, child: Scaffold(
      appBar: AppBar(title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('KNUAF AI STUDIO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.1)),
        Text('CREATE • EDIT • PUBLISH', style: TextStyle(fontSize: 9, color: gold, letterSpacing: 2)),
      ]), actions: const [Padding(padding: EdgeInsets.symmetric(horizontal: 16), child: Icon(Icons.auto_awesome, color: gold))]),
      body: SafeArea(child: Stack(children: [
        IndexedStack(index: tab, children: pages),
        if (busy) Container(color: Colors.black54, child: Center(child: Card(color: panel, child: Padding(
          padding: const EdgeInsets.all(22), child: Column(mainAxisSize: MainAxisSize.min, children: [
            const CircularProgressIndicator(color: gold), const SizedBox(height: 14), Text(status, textAlign: TextAlign.center),
          ]),
        )))),
      ])),
      bottomNavigationBar: NavigationBar(backgroundColor: panel, indicatorColor: gold.withOpacity(.18),
        selectedIndex: tab, onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home, color: gold), label: 'خانه'),
          NavigationDestination(icon: Icon(Icons.subtitles_outlined), selectedIcon: Icon(Icons.subtitles, color: gold), label: 'زیرنویس'),
          NavigationDestination(icon: Icon(Icons.record_voice_over_outlined), selectedIcon: Icon(Icons.record_voice_over, color: gold), label: 'صدا'),
          NavigationDestination(icon: Icon(Icons.psychology_outlined), selectedIcon: Icon(Icons.psychology, color: gold), label: 'هوش مصنوعی'),
        ]),
    ));
  }
}
