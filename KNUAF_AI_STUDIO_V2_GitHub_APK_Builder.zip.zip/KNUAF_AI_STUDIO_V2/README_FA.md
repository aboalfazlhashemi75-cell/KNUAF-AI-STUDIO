# KNUAF AI STUDIO — بسته آماده ساخت APK (V2)

این بسته سورس Flutter به‌همراه گردش‌کار GitHub Actions است تا بدون نصب Flutter روی کامپیوتر شخصی، فایل APK ساخته شود.

## ساخت APK با کمترین کار

1. وارد GitHub شوید و یک Repository جدید و خالی با نام `knuaf-ai-studio` بسازید.
2. فایل ZIP را از حالت فشرده خارج کنید.
3. تمام محتویات پوشه پروژه را در Repository بارگذاری کنید؛ پوشه مخفی `.github` و فایل داخل آن هم باید بارگذاری شود.
4. نام شاخه اصلی را `main` قرار دهید.
5. از بخش **Actions**، گردش‌کار **Build KNUAF AI STUDIO APK** را اجرا کنید (یا پس از push خودکار اجرا می‌شود).
6. بعد از پایان موفق، وارد اجرای workflow شوید و از قسمت **Artifacts** فایل `KNUAF-AI-STUDIO-APK` را دانلود کنید.
7. ZIP دانلودشده را باز کنید؛ فایل `app-release.apk` داخل آن است.

## نکته مهم درباره امکانات آنلاین

ساخت APK به‌تنهایی سرویس‌های هوش مصنوعی را فعال نمی‌کند. برای زیرنویس، تولید صدا و کپشن باید backend در یک سرور HTTPS اجرا شود.

برای اتصال سرور:
- در GitHub Repository به Settings → Secrets and variables → Actions → Variables بروید.
- یک Variable با نام `KNUAF_API_URL` و مقدار آدرس HTTPS سرور خود بسازید؛ مانند `https://api.example.com` (بدون اسلش انتهایی).
- سپس workflow را دوباره اجرا کنید.

کلید `OPENAI_API_KEY` باید فقط روی سرور backend تنظیم شود و هرگز داخل APK قرار نگیرد.

## ساخت دستی (در صورت نصب Flutter و Android SDK)

از ریشه پروژه:
```bash
flutter create --platforms=android --org com.knuafhashemi .
flutter pub get
flutter build apk --release
```

خروجی:
`build/app/outputs/flutter-apk/app-release.apk`

## وضعیت فعلی محصول

این نسخه یک نمونه اولیه قابل ساخت است؛ انتخاب و پیش‌نمایش ویدئو و اتصال به APIها در آن وجود دارد. هنوز ویرایشگر کامل هم‌سطح InShot نیست. برش و تدوین چندلایه، رندر نهایی ویدئو، زیرنویس چسبیده به تصویر، انتخاب و پخش صدای نریشن در خود اپ و تحلیل واقعی فریم‌های ویدئو باید در مراحل بعد توسعه داده شوند.

## سرور

راهنمای راه‌اندازی backend در `backend/` و نسخه فارسی قبلی پروژه قرار داشت. برای اجرای واقعی، فایل `backend/requirements.txt` و `backend/main.py` را بررسی کنید. قبل از استفاده عمومی، احراز هویت، HTTPS، محدودیت حجم ویدئو، rate limit، حذف امن فایل‌های موقت و سیاست حریم خصوصی اضافه شود.
